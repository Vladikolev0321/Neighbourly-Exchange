const products = [
    { id: 1, name: 'Smartphone', category: 'electronics', price: 400, rating: 5, image: '1.jpg' },
    { id: 2, name: 'Shirt', category: 'clothing', price: 30, rating: 3, image: '2.jpg' },
    { id: 3, name: 'Laptop', category: 'electronics', price: 1500, rating: 4, image: '3.jpg' },
    { id: 4, name: 'Book', category: 'books', price: 20, rating: 5, image: '4.jpg' },
    { id: 5, name: 'Bag', category: 'clothing', price: 80, rating: 2, image: '5.jpg' },
    { id: 6, name: 'Gaming Mouse', category: 'electronics', price: 120, rating: 4, image: '6.jpg' },
    { id: 7, name: 'Dress', category: 'clothing', price: 150, rating: 5, image: '7.jpg' },
    { id: 8, name: 'The Magic of Books', category: 'books', price: 15, rating: 3, image: '8.jpg' },
    { id: 9, name: 'Bluetooth Headphones', category: 'electronics', price: 90, rating: 4, image: '9.jpg' },
    { id: 10, name: 'Coffee Mug', category: 'clothing', price: 25, rating: 5, image: '10.jpg' }
];

function displayProducts(productsToDisplay) {
    const productList = document.getElementById('product-list');
    productList.innerHTML = '';

    productsToDisplay.forEach(product => {
        const productItem = document.createElement('div');
        productItem.classList.add('product-item');
        
        productItem.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>Price: ${product.price} BGN</p>
            <div class="rating">${'★'.repeat(product.rating)}${'☆'.repeat(5 - product.rating)}</div>
        `;
        
        productList.appendChild(productItem);
    });
}

function filterProducts() {
    const categoryFilter = document.getElementById('category').value;
    const priceFilter = document.getElementById('price').value;
    const ratingFilter = document.getElementById('rating').value;
    const searchFilter = document.getElementById('search').value.toLowerCase();

    const filteredProducts = products.filter(product => {
        let categoryMatch = (categoryFilter === 'all' || product.category === categoryFilter);
        let priceMatch = (priceFilter === 'all' ||
            (priceFilter === 'low' && product.price <= 50) ||
            (priceFilter === 'medium' && product.price > 50 && product.price <= 200) ||
            (priceFilter === 'high' && product.price > 200)
        );
        let ratingMatch = (ratingFilter === 'all' || product.rating == ratingFilter);
        let searchMatch = product.name.toLowerCase().includes(searchFilter);

        return categoryMatch && priceMatch && ratingMatch && searchMatch;
    });

    displayProducts(filteredProducts);
}

// Display all products by default
window.onload = function() {
    displayProducts(products);
};
